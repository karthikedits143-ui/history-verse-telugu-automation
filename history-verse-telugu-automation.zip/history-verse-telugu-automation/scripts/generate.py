#!/usr/bin/env python3
"""Generate Telugu History Verse draft assets using only Python's standard library."""
import csv
import json
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "config" / "topics.json"
OUT = ROOT / "output"

def build_long(topic, channel):
    return f"""# {topic['topic']}
## {channel} | Long-video Telugu narration draft

[HOOK — మొదటి 15 సెకన్లు]
ఒక చరిత్రాత్మక సంఘటన… ఎన్నో ప్రశ్నలు… కానీ నిజంగా ఏం జరిగింది?
ఈ రోజు మనం తెలుసుకోబోయేది: {topic['topic']}.

[INTRO]
నమస్కారం! మీరు చూస్తున్నది {channel}. చరిత్రలోని ఆసక్తికరమైన కథలను ఆధారాలతో తెలుసుకుందాం.

[BACKGROUND]
ఈ అంశాన్ని అర్థం చేసుకోవాలంటే ముందుగా దాని కాలం, ప్రాంతం, అప్పటి పరిస్థితులను తెలుసుకోవాలి.
వీడియో తయారీకి ముందు నిర్ధారిత తేదీలు, వ్యక్తుల పేర్లు, ప్రదేశాలు, ప్రాథమిక ఆధారాలను చేర్చండి.

[MAIN STORY]
ఈ వీడియో ప్రధాన కోణం: {topic['angle']}.
1. సంఘటనకు ముందు ఉన్న పరిస్థితులు ఏమిటి?
2. ముఖ్యమైన వ్యక్తులు లేదా సమూహాలు ఎవరు?
3. అందుబాటులో ఉన్న చారిత్రక ఆధారాలు ఏమి చెబుతున్నాయి?
4. ఈ సంఘటన తరువాత ఏమి మారింది?

[WHAT IS KNOWN / WHAT IS UNCERTAIN]
నిర్ధారిత సమాచారం, పరిశోధకుల అభిప్రాయాలు, ప్రజాదరణ పొందిన కథనాలు వేర్వేరు.
ఆధారం లేని కథనాన్ని నిజమని చెప్పకండి. వివాదాస్పద అంశాలను స్పష్టంగా గుర్తించండి.

[ENDING]
ఈ కథలో మీకు అత్యంత ఆసక్తికరంగా అనిపించిన విషయం ఏది? కామెంట్‌లో చెప్పండి.
ఇలాంటి చరిత్ర, మిస్టరీ కథల కోసం History Verse Teluguని Subscribe చేయండి.

EDITOR NOTE: ఇది నిర్మాణాత్మక డ్రాఫ్ట్ మాత్రమే; పూర్తి పరిశోధన చేసిన స్క్రిప్ట్ కాదు.
ప్రచురణకు ముందు ప్రతి తేదీ, పేరు, వాదనను విశ్వసనీయ మూలాలతో ధృవీకరించండి.
"""

def build_short(topic):
    return f"""# YouTube Shorts — {topic['topic']}

[0–3 sec | HOOK]
మీకు తెలుసా? {topic['topic']} వెనుక ఒక ఆసక్తికరమైన చరిత్ర ఉంది!

[3–15 sec | SETUP]
ఈ కథలో ముఖ్యమైన విషయం: {topic['angle']}.

[15–43 sec | STORY]
ధృవీకరించిన ఒక ముఖ్యమైన వాస్తవం, దానికి సంబంధించిన తేదీ లేదా ఆధారం, దాని ప్రాముఖ్యతను సులభమైన తెలుగులో వివరించండి.
ఒకే ప్రధాన ఆలోచనపై దృష్టి పెట్టండి. ఊహాగానాలను వాస్తవాలుగా చెప్పకండి.

[43–55 sec | CTA]
ఇలాంటి చరిత్ర కథల కోసం History Verse Teluguని Subscribe చేయండి!
"""

def main():
    with CONFIG.open("r", encoding="utf-8") as f:
        config = json.load(f)
    topics = config.get("topics", [])
    if not topics:
        raise ValueError("Add at least one topic in config/topics.json")
    today = date.today()
    topic = topics[today.toordinal() % len(topics)]
    OUT.mkdir(exist_ok=True)
    stem = today.isoformat()

    (OUT / f"{stem}-long-script.md").write_text(build_long(topic, config["channel_name"]), encoding="utf-8")
    (OUT / f"{stem}-short-script.md").write_text(build_short(topic), encoding="utf-8")

    description = (
        f"{topic['topic']} గురించి తెలుగులో తెలుసుకుందాం.\n\n"
        "ఈ వీడియోలో చారిత్రక నేపథ్యం, ఆధారాలు, ఆసక్తికరమైన ప్రశ్నలను పరిశీలిస్తాం.\n"
        "ఇలాంటి కథల కోసం History Verse Teluguని Subscribe చేయండి.\n\n"
        "#HistoryVerseTelugu #TeluguHistory #History #Mystery #Telugu"
    )
    metadata = (
        f"# Upload metadata\n\n**Title:** {topic['topic']} | Telugu History & Mystery\n\n"
        f"**Description:**\n{description}\n\n"
        "**Tags:** History Verse Telugu, Telugu history, history in Telugu, mystery in Telugu, Indian history, world history, archaeology\n"
    )
    (OUT / f"{stem}-metadata.md").write_text(metadata, encoding="utf-8")

    rows = [
        ["00:00-00:15", "Hook", "Topic-related licensed visual", "Opening question"],
        ["00:15-00:45", "Context", "Map, timeline, location visuals", "Introduce period and place"],
        ["00:45-02:00", "Background", "Archival or public-domain visuals", "Explain verified context"],
        ["02:00-04:30", "Main story", "Evidence photos, diagrams, maps", "Explain key events"],
        ["04:30-05:30", "Evidence and uncertainty", "Sources and timeline", "Separate facts from theories"],
        ["05:30-end", "Conclusion", "Channel end screen", "Question and subscribe prompt"]
    ]
    with (OUT / f"{stem}-storyboard.csv").open("w", encoding="utf-8-sig", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["time", "section", "visual_direction", "narration_goal"])
        writer.writerows(rows)
    print(f"Generated drafts for: {topic['topic']}")

if __name__ == "__main__":
    main()
