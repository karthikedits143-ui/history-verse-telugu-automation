# History Verse Telugu — Free Automation Starter

A zero-cost starter workflow for Telugu History & Mystery drafts for Shorts and long videos.

## What it does
- Runs daily at 6:00 AM India time (00:30 UTC), or manually from GitHub Actions.
- Creates a Telugu long-video narration draft, a 45–60 second Shorts draft, upload metadata, and a storyboard CSV.
- Uploads the files as a downloadable GitHub Actions artifact.

## Important limitations
This creates content drafts, not finished videos. It does not automatically research facts, generate AI voice/video, or upload to YouTube. Verify historical claims, record narration, add licensed visuals, edit, and upload manually. Free AI services have changing limits and may require accounts or paid credits.

## Run it
1. Open the Actions tab in this repository and enable Actions if prompted.
2. Select "Daily Telugu content drafts" → "Run workflow".
3. Open the completed run and download the "history-verse-drafts" artifact.
4. Review the files before publishing.

## Customize topics
Edit `config/topics.json`. Add objects with `topic`, `category`, and `angle`. The generator rotates through the topic list based on the current date.

## Production checklist
1. Verify dates, names, locations, and claims using trustworthy sources.
2. Record Telugu narration or use a voice service whose terms permit YouTube use.
3. Use original, licensed, public-domain, or properly attributed visuals.
4. Edit in VN, CapCut, or FFmpeg.
5. Check copyright, facts, pronunciation, subtitles, and YouTube policies.
6. Upload through YouTube Studio.

No paid API key or third-party Python package is required for this starter.


## Optional audio and simple video generation
The workflow also installs FFmpeg and `edge-tts`, then runs `scripts/produce_media.py`.
It creates Telugu narration MP3 files and simple MP4 drafts using static branded backgrounds.
The default voice is `te-IN-ShrutiNeural`; change `VOICE` in the script if you prefer another supported Telugu voice.
This requires internet access and a third-party TTS endpoint. Availability and terms can change.
The MP4s are basic audio-plus-background drafts, not fully edited documentary videos: add researched visuals, motion, subtitles, and transitions before publishing.
