#!/usr/bin/env python3
"""Create Telugu narration audio and simple MP4 drafts with Edge TTS + FFmpeg.

Requires internet access for Edge TTS and ffmpeg installed on the machine/runner.
This uses a third-party online TTS endpoint; availability and terms can change.
"""
import asyncio
import re
import subprocess
from pathlib import Path

import edge_tts

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "output"
ASSETS = ROOT / "assets"
VOICE = "te-IN-ShrutiNeural"

def clean_script(path: Path) -> str:
    text = path.read_text(encoding="utf-8")
    lines = []
    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("#") or s.startswith("[") or s.startswith("EDITOR NOTE:"):
            continue
        if s.startswith("---") or s.startswith("1.") or s.startswith("2.") or s.startswith("3.") or s.startswith("4."):
            continue
        lines.append(s)
    return re.sub(r"\s+", " ", " ".join(lines)).strip()

async def make_audio(text: str, destination: Path):
    if not text:
        raise ValueError("No narration text found in generated script.")
    communicator = edge_tts.Communicate(text, VOICE)
    await communicator.save(str(destination))

def make_video(audio: Path, destination: Path, background: Path, width: int, height: int):
    if not background.exists():
        raise FileNotFoundError(f"Missing background image: {background}")
    cmd = [
        "ffmpeg", "-y", "-loop", "1", "-i", str(background), "-i", str(audio),
        "-vf", f"scale={width}:{height}:force_original_aspect_ratio=increase,crop={width}:{height}",
        "-c:v", "libx264", "-tune", "stillimage", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "192k", "-shortest", str(destination)
    ]
    subprocess.run(cmd, check=True)

async def main():
    OUT.mkdir(exist_ok=True)
    long_script = sorted(OUT.glob("*-long-script.md"))
    short_script = sorted(OUT.glob("*-short-script.md"))
    if not long_script or not short_script:
        raise FileNotFoundError("Run scripts/generate.py first to create narration drafts.")
    long_text = clean_script(long_script[-1])
    short_text = clean_script(short_script[-1])

    long_audio = OUT / "long-narration.mp3"
    short_audio = OUT / "short-narration.mp3"
    await make_audio(long_text, long_audio)
    await make_audio(short_text, short_audio)

    make_video(long_audio, OUT / "long-video-draft.mp4", ASSETS / "background-16x9.png", 1920, 1080)
    make_video(short_audio, OUT / "short-video-draft.mp4", ASSETS / "background-9x16.png", 1080, 1920)
    print("Created Telugu narration MP3 files and simple MP4 video drafts.")

if __name__ == "__main__":
    asyncio.run(main())
